/**
 * Momenten - beheer. Momenten toevoegen, verwijderen en verplaatsen.
 * De volgorde in het scherm is de volgorde die wordt opgeslagen.
 */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var lijst = document.getElementById('momenten-lijst');
		var tmpl = document.getElementById('moment-template');
		var toevoegen = document.getElementById('moment-toevoegen');

		// Nummer de momenten opnieuw (1, 2, 3, ...) op basis van de volgorde.
		function hernummer() {
			if (!lijst) { return; }
			var kaarten = lijst.querySelectorAll('.momenten-kaart');
			for (var i = 0; i < kaarten.length; i++) {
				var nr = kaarten[i].querySelector('.momenten-nr');
				if (nr) { nr.textContent = String(i + 1); }
			}
		}
		hernummer();

		if (toevoegen && tmpl && lijst) {
			toevoegen.addEventListener('click', function () {
				var uniek = Date.now();
				var html = tmpl.innerHTML.replace(/__i__/g, String(uniek));
				var houder = document.createElement('div');
				houder.innerHTML = html.trim();
				var kaart = houder.firstElementChild;
				if (kaart) {
					lijst.appendChild(kaart);
					hernummer();
					kaart.scrollIntoView({ behavior: 'smooth', block: 'center' });
				}
			});
		}

		// Logo kiezen via de mediabibliotheek.
		var kiesLogo = document.getElementById('momenten-logo-kies');
		var verwijderLogo = document.getElementById('momenten-logo-verwijder');
		var logoVeld = document.getElementById('momenten_logo_url');
		var logoPreview = document.querySelector('.momenten-logo-preview');
		var mediaFrame = null;

		if (kiesLogo && logoVeld && window.wp && window.wp.media) {
			kiesLogo.addEventListener('click', function (e) {
				e.preventDefault();
				if (mediaFrame) { mediaFrame.open(); return; }
				mediaFrame = window.wp.media({
					title: 'Kies een logo',
					library: { type: 'image' },
					multiple: false,
					button: { text: 'Gebruiken' }
				});
				mediaFrame.on('select', function () {
					var att = mediaFrame.state().get('selection').first().toJSON();
					logoVeld.value = att.url;
					if (logoPreview) {
						logoPreview.innerHTML = '';
						var img = document.createElement('img');
						img.src = att.url;
						img.alt = '';
						logoPreview.appendChild(img);
					}
				});
				mediaFrame.open();
			});
		}
		if (verwijderLogo && logoVeld) {
			verwijderLogo.addEventListener('click', function (e) {
				e.preventDefault();
				logoVeld.value = '';
				if (logoPreview) { logoPreview.innerHTML = ''; }
			});
		}

		// Herbruikbare mediakiezer (voor de pop-up-afbeelding).
		function koppelMediaKiezer(kiesId, verwijderId, veldId, previewSel, titel) {
			var kies = document.getElementById(kiesId);
			var verwijder = document.getElementById(verwijderId);
			var veld = document.getElementById(veldId);
			var preview = document.querySelector(previewSel);
			var frame = null;
			if (kies && veld && window.wp && window.wp.media) {
				kies.addEventListener('click', function (e) {
					e.preventDefault();
					if (frame) { frame.open(); return; }
					frame = window.wp.media({ title: titel, library: { type: 'image' }, multiple: false, button: { text: 'Gebruiken' } });
					frame.on('select', function () {
						var att = frame.state().get('selection').first().toJSON();
						veld.value = att.url;
						if (preview) {
							preview.innerHTML = '';
							var img = document.createElement('img');
							img.src = att.url;
							img.alt = '';
							preview.appendChild(img);
						}
					});
					frame.open();
				});
			}
			if (verwijder && veld) {
				verwijder.addEventListener('click', function (e) {
					e.preventDefault();
					veld.value = '';
					if (preview) { preview.innerHTML = ''; }
				});
			}
		}

		// Afbeelding kiezen voor de pop-up (tweede mediakiezer).
		koppelMediaKiezer('momenten-popupimg-kies', 'momenten-popupimg-verwijder', 'momenten_popupimg_url', '.momenten-popupimg-preview', 'Kies een afbeelding');

		document.addEventListener('click', function (e) {
			var t = e.target;
			if (!t) { return; }
			var kaart = t.closest ? t.closest('.momenten-kaart') : null;

			if (t.classList.contains('moment-verwijder')) {
				e.preventDefault();
				if (kaart && window.confirm('Dit moment verwijderen?')) {
					kaart.parentNode.removeChild(kaart);
					hernummer();
				}
			} else if (t.classList.contains('moment-omhoog')) {
				e.preventDefault();
				if (kaart && kaart.previousElementSibling) {
					kaart.parentNode.insertBefore(kaart, kaart.previousElementSibling);
					hernummer();
				}
			} else if (t.classList.contains('moment-omlaag')) {
				e.preventDefault();
				if (kaart && kaart.nextElementSibling) {
					kaart.parentNode.insertBefore(kaart.nextElementSibling, kaart);
					hernummer();
				}
			}
		});
	});
})();
